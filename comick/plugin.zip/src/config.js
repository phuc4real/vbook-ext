let BASE = "https://comick.io/";
let COMIC = "https://comick.io/comic/";
let SEARCH = "https://api.comick.io/v1.0/search";
let CHAP = "https://api.comick.io/comic/";
let IMG = "https://meo.comick.pictures/";
let GENRES = "https://comick.io/_next/data/.d2b57eb7bb777c779aa543b306494dec60b03d1a/search.json";
let LANG = "en";